export interface ProductionPlan {
  id: string;
  name: string;
  startDate: string;
  endDate: string;
  status: 'draft' | 'active' | 'completed';
  description: string;
}

export interface Resource {
  id: string;
  name: string;
  type: 'human' | 'machine' | 'material';
  availability: boolean;
  capacity: number;
}

export interface ScheduleItem {
  id: string;
  productionPlanId: string;
  resourceId: string;
  startTime: string;
  endTime: string;
  task: string;
}

export interface StockItem {
  id: string;
  name: string;
  quantity: number;
  unit: string;
  minimumStock: number;
  location: string;
}