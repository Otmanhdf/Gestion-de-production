import React, { useState } from 'react';
import { Users, Plus } from 'lucide-react';
import type { Resource } from '../../types/production';

export default function ResourceManagement() {
  const [resources] = useState<Resource[]>([
    {
      id: '1',
      name: 'Machine A',
      type: 'machine',
      availability: true,
      capacity: 100
    },
    {
      id: '2',
      name: 'Équipe Production',
      type: 'human',
      availability: true,
      capacity: 8
    }
  ]);

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-xl font-bold flex items-center">
          <Users className="w-6 h-6 mr-2 text-blue-600" />
          Gestion des Ressources
        </h3>
        <button className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex items-center">
          <Plus className="w-4 h-4 mr-2" />
          Ajouter une Ressource
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nom</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Disponibilité</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Capacité</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {resources.map((resource) => (
              <tr key={resource.id}>
                <td className="px-6 py-4 whitespace-nowrap">{resource.name}</td>
                <td className="px-6 py-4 whitespace-nowrap capitalize">{resource.type}</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                    resource.availability ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                  }`}>
                    {resource.availability ? 'Disponible' : 'Indisponible'}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">{resource.capacity}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  <button className="text-blue-600 hover:text-blue-900">Modifier</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}