import React from 'react';
import { Calendar, Clock } from 'lucide-react';
import type { ScheduleItem } from '../../types/production';

export default function Scheduling() {
  const scheduleItems: ScheduleItem[] = [
    {
      id: '1',
      productionPlanId: 'plan1',
      resourceId: 'resource1',
      startTime: '2024-03-20T08:00',
      endTime: '2024-03-20T16:00',
      task: 'Production Lot A'
    }
  ];

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-xl font-bold flex items-center">
          <Calendar className="w-6 h-6 mr-2 text-blue-600" />
          Ordonnancement de la Production
        </h3>
      </div>

      <div className="space-y-4">
        {scheduleItems.map((item) => (
          <div key={item.id} className="border rounded-lg p-4">
            <div className="flex items-center justify-between">
              <h4 className="font-semibold">{item.task}</h4>
              <div className="flex items-center text-gray-600">
                <Clock className="w-4 h-4 mr-1" />
                <span className="text-sm">
                  {new Date(item.startTime).toLocaleTimeString()} - 
                  {new Date(item.endTime).toLocaleTimeString()}
                </span>
              </div>
            </div>
            <div className="mt-2 text-sm text-gray-600">
              Date: {new Date(item.startTime).toLocaleDateString()}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}