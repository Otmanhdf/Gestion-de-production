import React, { useState } from 'react';
import { Package, AlertCircle } from 'lucide-react';
import type { StockItem } from '../../types/production';

export default function StockManagement() {
  const [stockItems] = useState<StockItem[]>([
    {
      id: '1',
      name: 'Matière première A',
      quantity: 150,
      unit: 'kg',
      minimumStock: 100,
      location: 'Zone A'
    },
    {
      id: '2',
      name: 'Composant B',
      quantity: 50,
      unit: 'pcs',
      minimumStock: 75,
      location: 'Zone B'
    }
  ]);

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h3 className="text-xl font-bold mb-6 flex items-center">
        <Package className="w-6 h-6 mr-2 text-blue-600" />
        Gestion des Stocks
      </h3>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {stockItems.map((item) => {
          const isLowStock = item.quantity < item.minimumStock;
          return (
            <div key={item.id} className="border rounded-lg p-4">
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="font-semibold">{item.name}</h4>
                  <p className="text-sm text-gray-600">Emplacement: {item.location}</p>
                </div>
                {isLowStock && (
                  <AlertCircle className="w-5 h-5 text-red-500" />
                )}
              </div>
              <div className="mt-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Quantité actuelle:</span>
                  <span className={`font-medium ${isLowStock ? 'text-red-600' : 'text-green-600'}`}>
                    {item.quantity} {item.unit}
                  </span>
                </div>
                <div className="flex justify-between items-center mt-1">
                  <span className="text-sm text-gray-600">Stock minimum:</span>
                  <span className="text-sm">{item.minimumStock} {item.unit}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}