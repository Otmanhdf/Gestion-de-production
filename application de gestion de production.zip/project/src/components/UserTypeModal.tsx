import React from 'react';
import { Users, UserCog, HardHat } from 'lucide-react';

interface UserTypeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectRole: (role: string) => void;
}

export default function UserTypeModal({ isOpen, onClose, onSelectRole }: UserTypeModalProps) {
  if (!isOpen) return null;

  const roles = [
    { id: 'admin', title: 'Administrateur', icon: Users },
    { id: 'production-manager', title: 'Responsable de Production', icon: UserCog },
    { id: 'operator', title: 'Opérateur', icon: HardHat },
  ];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
      <div className="bg-white rounded-lg p-6 w-96">
        <h2 className="text-2xl font-bold mb-4 text-gray-800">Sélectionnez votre rôle</h2>
        <div className="space-y-3">
          {roles.map((role) => {
            const Icon = role.icon;
            return (
              <button
                key={role.id}
                onClick={() => onSelectRole(role.id)}
                className="w-full flex items-center p-4 bg-gray-50 hover:bg-blue-50 rounded-lg transition-colors"
              >
                <Icon className="w-6 h-6 mr-3 text-blue-600" />
                <span className="text-gray-700 font-medium">{role.title}</span>
              </button>
            );
          })}
        </div>
        <button
          onClick={onClose}
          className="mt-4 w-full p-2 bg-gray-200 hover:bg-gray-300 rounded-lg text-gray-700"
        >
          Fermer
        </button>
      </div>
    </div>
  );
}