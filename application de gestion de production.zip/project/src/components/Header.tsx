import React from 'react';
import { Factory } from 'lucide-react';

export default function Header() {
  return (
    <header className="bg-blue-600 text-white p-4">
      <div className="container mx-auto flex items-center">
        <Factory className="w-8 h-8 mr-2" />
        <h1 className="text-2xl font-bold">TechPro Industries</h1>
      </div>
    </header>
  );
}