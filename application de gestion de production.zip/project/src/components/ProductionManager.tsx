import React, { useState } from 'react';
import { ClipboardList, Calendar, Users, Package } from 'lucide-react';
import CreatePlan from './production/CreatePlan';
import Scheduling from './production/Scheduling';
import ResourceManagement from './production/ResourceManagement';
import StockManagement from './production/StockManagement';

export default function ProductionManager() {
  const [activeView, setActiveView] = useState<string | null>(null);

  const modules = [
    {
      id: 'create-plan',
      icon: ClipboardList,
      title: 'Créer Plan de Production',
      description: 'Élaborer et gérer les plans de production',
      component: CreatePlan
    },
    {
      id: 'scheduling',
      icon: Calendar,
      title: 'Gérer l\'Ordonnancement',
      description: 'Planifier et optimiser les séquences de production',
      component: Scheduling
    },
    {
      id: 'resources',
      icon: Users,
      title: 'Gérer les Ressources',
      description: 'Allouer et superviser les ressources de production',
      component: ResourceManagement
    },
    {
      id: 'stock',
      icon: Package,
      title: 'Consulter le Stock',
      description: 'Suivre les niveaux de stock et les approvisionnements',
      component: StockManagement
    }
  ];

  return (
    <div className="container mx-auto p-6">
      <h2 className="text-2xl font-bold mb-6 text-gray-800">
        Tableau de Bord - Responsable de Production
      </h2>

      {!activeView ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {modules.map((module) => {
            const Icon = module.icon;
            return (
              <div
                key={module.id}
                className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow cursor-pointer"
                onClick={() => setActiveView(module.id)}
              >
                <div className="flex items-center mb-4">
                  <Icon className="w-8 h-8 text-blue-600 mr-3" />
                  <h3 className="text-xl font-semibold text-gray-800">{module.title}</h3>
                </div>
                <p className="text-gray-600">{module.description}</p>
              </div>
            );
          })}
        </div>
      ) : (
        <div>
          <button
            onClick={() => setActiveView(null)}
            className="mb-4 px-4 py-2 text-blue-600 hover:bg-blue-50 rounded-md"
          >
            ← Retour au tableau de bord
          </button>
          
          {modules.map((module) => 
            module.id === activeView && <module.component key={module.id} />
          )}
        </div>
      )}
    </div>
  );
}