import React, { useState } from 'react';
import Header from './components/Header';
import UserTypeModal from './components/UserTypeModal';
import ProductionManager from './components/ProductionManager';

function App() {
  const [showModal, setShowModal] = useState(false);
  const [selectedRole, setSelectedRole] = useState<string | null>(null);

  const handleRoleSelect = (role: string) => {
    setSelectedRole(role);
    setShowModal(false);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      
      {!selectedRole && (
        <main className="container mx-auto p-6">
          <div className="max-w-4xl mx-auto text-center">
            <img
              src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80"
              alt="Production Planning"
              className="w-full h-64 object-cover rounded-lg mb-8"
            />
            
            <h2 className="text-3xl font-bold text-gray-800 mb-4">
              Système de Gestion de la Planification de Production
            </h2>
            
            <p className="text-gray-600 mb-8">
              Optimisez votre production avec notre solution complète de planification et de gestion.
              Gérez efficacement vos ressources, suivez votre production en temps réel et prenez
              des décisions éclairées.
            </p>
            
            <button
              onClick={() => setShowModal(true)}
              className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
            >
              Commencer
            </button>
          </div>
        </main>
      )}

      {selectedRole === 'production-manager' && <ProductionManager />}
      
      <UserTypeModal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        onSelectRole={handleRoleSelect}
      />
    </div>
  );
}

export default App;